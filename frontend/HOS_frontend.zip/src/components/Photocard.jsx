import "../components-css/Photocard.css";

export const Photocard = () => {
    return (
        <>
            <div className="gallery-container">
                <div className="card">
                    <img src="/a.jpg" alt="Hostel" />
                </div>
                <div className="card">
                    <img src="/a.jpg" alt="Hostel" />
                </div>
                <div className="card">
                    <img src="/a.jpg" alt="Hostel" />
                </div>
                <div className="card">
                    <img src="/a.jpg" alt="Hostel" />
                </div>
                <div className="card">
                    <img src="/a.jpg" alt="Hostel" />
                </div>
            </div>
        </>
    )
}